# Define paths

$outputFolderPath = "C:\Users\vinson\OneDrive - F5, Inc\homedepot-ps-labor\BrianVinson_summaries\CSExtract"

$sourceFilePath = "C:\Users\vinson\OneDrive - F5, Inc\homedepot-ps-labor\BrianVinson_summaries\CSExtract\cs-vs-qp-80-v1-webapps.json"  
##$sourceFilePath = "C:\Users\vinson\OneDrive - F5, Inc\homedepot-ps-labor\BrianVinson_summaries\CSExtract\cs-vs-qp-80-v1-webbatch.json"
##$sourceFilePath = "C:\Users\vinson\OneDrive - F5, Inc\homedepot-ps-labor\BrianVinson_summaries\CSExtract\cs-vs-qp-443-v1-webapps.json"
##$sourceFilePath = "C:\Users\vinson\OneDrive - F5, Inc\homedepot-ps-labor\BrianVinson_summaries\CSExtract\cs-vs-qp-443-v1-webbatch.json"

$collectText = $false
$output = @()
# Read the CSV file and loop through each row
Get-Content $sourceFilePath | ForEach-Object {
    # Initialize collection variables

    # Check for 'name:' line and capture the name value
    if ($_ -match '^(?i)name:\s*(\S+)') {
        $nameValue = $matches[1]
        $outputFileName = "$outputFolderPath\$nameValue.json"
        Write-Host "I found an entry of $nameValue"
        # Name found, start collecting text
        $collectText = $true
    }
    # Check for delimiter and stop collecting text
    if ($_ -eq '-') {
        # Delimiter found, stop collecting text
        # Remove the last line collected
        
        $output += "diagnostics: []"
        $collectText = $false
        # Convert collected text to JSON
        $jsonOutput = $output 

        # Write JSON output to file
        Set-Content -Path $outputFileName -Value $jsonOutput
        Write-Host "Output for $nameValue written to $outputFileName"

        # Reset output collection
        $output = @()
    }

    # Collect text lines if collection has started
    if ($collectText) {
        $output += $_ 
    }
}

Write-Host "Processing complete. Output files are in $outputFolderPath"
