$inputDirectory = "C:\Users\karce\OneDrive - F5, Inc\Documents\Consulting\FIS_Script\lrdaa01_output"
## Add SNAT Pool in Commons
# Iterate through each file in the input directory
Get-ChildItem -Path $inputDirectory | ForEach-Object {
    $inputFile = $_.FullName
    # Read the content of the input file
    $content = Get-Content -Path $inputFile -Raw
    $parsedObject = ConvertFrom-Yaml -Yaml $content
    # Initialize variables to store parsed values
    $virtualAddress = $virtualPort = $type = $protocol = ""
    $persistenceType = $persistenceBackup = $lbMethod = ""
    $dnsQuery = $dnsQueryType = $persistenceValueAS3 = ""
    $serverTimeout = $clientTimeout = "300"
    $poolMembers = @()
    $lbMethodAlgorithm = "round-robin"
    $fullName = $parsedObject.name
    #extract Tenant mame from fullname
    if ($fullName -match '^[^-]+-[^-]+-([^-]+)-') {
        $tenant = $matches[1]
        Write-Host "Found tenant: $tenant"
    } else {
        Write-Host "No match found"
    }
    $protocol = $parsedObject.protocol
    #Write-Host "Found protocol: $protocol"
    $virtualAddress = $parsedObject.ipAddress
    #Write-Host "Found IP $virtualAddress"    
    $virtualPort = $parsedObject.port
    #Write-Host "Found Virtal Port $virtualPort" 
    $type = $parsedObject.type
    #Write-Host "Found Type $type"
    #Connect the Opts
    foreach ($key in $parsedObject.opts.Keys) {
        #Write-Output "$key key equals value $($parsedObject.opts[$key])"
        if ($key -eq "-persistenceType") {
            $persistenceType = $($parsedObject.opts[$key])
            #Write-Host "Found persistenceType: $persistenceType"
            switch ($persistenceType) {
                    COOKIEINSERT { $persistenceValueAS3 += @"
                    {"bigip": "/Common/cookie"}
"@                    
                    }
                    SOURCEIP { $persistenceValueAS3 +=  @"
                    {"bigip": "/Common/source_addr"}
"@                     
                    }
                    NONE {}
                    Default {}
                }
        } elseif ($key -eq "-persistenceBackup") {
            $persistenceBackup = $($parsedObject.opts[$key])
            #Write-Host "Found persistenceBackup: $persistenceBackup"
            switch ($persistenceBackup) {
              COOKIEINSERT { $persistenceValueAS3 += @"
              {"bigip": "/Common/cookie"}
"@                    
              }
              SOURCEIP { $persistenceValueAS3 +=  @"
              {"bigip": "/Common/source_addr"}
"@                     
              }
              NONE {}
              Default {}
          }
        } elseif ($key -eq "-lbMethod") {
          $lbMethod = $($parsedObject.opts[$key])
          #Write-Host "Found lbMethod: $lbMethod"
          switch ($lbMethod) {
            ROUNDROBIN { $lbMethodAlgorithm = "round-robin" }
            LEASTCONNECTION { $lbMethodAlgorithm = "least-connections-member" }
            LEASTRESPONSETIME { $lbMethodAlgorithm = "least-connections-node" }
            TOKEN { $lbMethodAlgorithm = "least-sessions" }
            Default { $lbMethodAlgorithm = "round-robin" }
          }
        } elseif ($key -eq "-cltTimeout") {
          #Write-Host "Client Timeout $($parsedObject.opts[$key])"
          if ($($parsedObject.opts[$key]) -eq 9000) {
            $clientTimeout = "300"
          } else {
            $clientTimeout = $($parsedObject.opts[$key])
          }
        } elseif ($key -eq "-svrTimeout") {
          #Write-Host "Server Timeout $($parsedObject.opts[$key])"
          if ($($parsedObject.opts[$key]) -eq 9000) {
            $serverTimeout = "300"
          } else {
            $serverTimeout = $($parsedObject.opts[$key])
          }
        }
    }

   if ($parsedObject.bindings) {
    foreach ($key in $parsedObject.bindings.Keys) {
      if ($key -eq "service") {
          foreach ($subkey in $parsedObject.bindings.service.Keys) {
            Write-Host "My Sub Key $subkey"
              if ($subkey -eq "name") {
                Write-Host "Redirect $($parsedObject.bindings.service.name)"
                if ($($parsedObject.bindings.service.name) -eq "lb-sv-http-to-https") { $protocol = "REDIRECT"}
                for ($i = 0; $i -lt $length; $i++ ) {
                  $poolMembers += @{
                    "name" =  $($parsedObject.bindings.serviceGroup.servers[$i].name)
                    "address" = $($parsedObject.bindings.serviceGroup.servers[$i].address)
                    "port" = $($parsedObject.bindings.serviceGroup.servers[$i].port)
                  }
                }
              }
          }
      } elseif ($key -eq "serviceGroup") {
        foreach ($subkey in $parsedObject.bindings.serviceGroup.Keys) {
          #Write-Host "In Service Group Loop $subkey"
          if ($subkey -eq 'servers') {
              $length = $parsedObject.bindings.serviceGroup.servers.length
              if ($length -eq 1) {
                #Write-Host "Its a one length"
                $poolMembers += @{
                  "name" =  $($parsedObject.bindings.serviceGroup.servers.name)
                  "address" = $($parsedObject.bindings.serviceGroup.servers.address)
                  "port" = $($parsedObject.bindings.serviceGroup.servers.port)
                }
              } else {
                #Write-Host "In Service Group Servers length $length"
                for ($i = 0; $i -lt $length; $i++ ) {
                  $poolMembers += @{
                    "name" =  $($parsedObject.bindings.serviceGroup.servers[$i].name)
                    "address" = $($parsedObject.bindings.serviceGroup.servers[$i].address)
                    "port" = $($parsedObject.bindings.serviceGroup.servers[$i].port)
                  }
                }
              }
            } elseif ($subkey -eq "monitors") {
            foreach ($monelement in $parsedObject.bindings.serviceGroup.monitors.Keys) {
              #Write-Host "Monitors Found $monelement"
              switch ($monelement) { 
                -query {$dnsQuery = $($parsedObject.bindings.serviceGroup.monitors.'-query')}
                -queryType {
                   switch ($($parsedObject.bindings.serviceGroup.monitors.'-queryType')) {
                    Address {$dnsQueryType = "a"}
                   }
                -send {}
                -recv {}
                -interval {}
                }
              }
            }
          }
        }
      }
    } 
  }

# Generate pool members JSON
#Write-Host "Pool Members before JSON $poolMembers"
$poolMembersJson = ($poolMembers | ForEach-Object {
    @"
    {
      "addressDiscovery": "static",
      "shareNodes": true,
      "servicePort": $($_.port),
      "servers": [
        {
          "name": "$($_.name)",
          "address": "$($_.address)"
        }
      ]
    }
"@
}) -join ","



    # Select the appropriate template based on the "type" and "protocol"
    #Write-Host "Selected template for protocol: $protocol" 
    $template = switch ($protocol) {
        "TCP" {
                #Write-Host "Selecting tcp template"
                @"
                {
                    "class": "AS3",
                    "action": "deploy",
                    "persist": true,
                    "declaration": {
                      "class": "ADC",
                      "schemaVersion": "3.50.0",
                      "$tenant": {
                        "class": "Tenant",
                       "${fullName}": {
                          "class": "Application",
                          "vs_${fullName}": {
                            "class": "Service_TCP",
                            "layer4": "tcp",
                            "pool": "pool_$fullname",
                            "translateServerAddress": true,
                            "translateServerPort": true,
                            "profileTCP": {
                              "ingress": {
                                "use": "client_tcp_$fullname"
                              },
                              "egress": {
                                "use": "server_tcp_$fullname"
                              }
                            },
                            "shareAddresses": true,
                            "virtualAddresses": [
                              "$virtualAddress"
                            ],
                            "virtualPort": $virtualPort,
                            "persistenceMethods": [
                            ${persistenceValueAS3}
                            ],
                            "snat": {
                              "bigip": "/Common/generalSNAT"
                            }
                          },
                          "pool_$fullname": {
                            "loadBalancingMode": "${lbMethodAlgorithm}",
                            "members": [
                                      $poolMembersJson
                            ],
                            "monitors": [
                              {
                                "bigip": "/Common/tcp"
                              }
                            ],
                            "class": "Pool"
                          },
                          "server_tcp_$fullname": {
                            "idleTimeout": $serverTimeout,
                            "class": "TCP_Profile"
                          },
                         "client_tcp_$fullname": {
                            "idleTimeout": $clientTimeout,
                            "class": "TCP_Profile"
                          }
                        }
                      }
                    }
                  }
"@
            }
"DNS_TCP" {
  #Write-Host "Selecting tcp template"
  @"
  {
      "class": "AS3",
      "action": "deploy",
      "persist": true,
      "declaration": {
        "class": "ADC",
        "schemaVersion": "3.50.0",
        "$tenant": {
          "class": "Tenant",
         "${fullName}": {
            "class": "Application",
            "vs_${fullName}": {
              "class": "Service_TCP",
              "layer4": "tcp",
              "pool": "pool_$fullname",
              "translateServerAddress": true,
              "translateServerPort": true,
              "profileTCP": {
                "ingress": {
                  "use": "client_tcp_$fullname"
                },
                "egress": {
                  "use": "server_tcp_$fullname"
                }
              },
              "shareAddresses": true,
              "virtualAddresses": [
                "$virtualAddress"
              ],
              "virtualPort": $virtualPort,
              "persistenceMethods": [
              ${persistenceValueAS3}
              ],
              "snat": {
                "bigip": "/Common/generalSNAT"
              }
            },
            "pool_$fullname": {
              "loadBalancingMode": "${lbMethodAlgorithm}",
              "members": [
                        $poolMembersJson
              ],
              "monitors": [
                {
                  "bigip": "/Common/tcp"
                }
              ],
              "class": "Pool"
            },
            "server_tcp_$fullname": {
              "idleTimeout": $serverTimeout,
              "class": "TCP_Profile"
            },
           "client_tcp_$fullname": {
              "idleTimeout": $clientTimeout,
              "class": "TCP_Profile"
            }
          }
        }
      }
    }
"@
}

"UDP" {
    #Write-Host "Selecting UDP template"
                @"
    {
        "class": "AS3",
        "action": "deploy",
        "persist": true,
        "declaration": {
          "class": "ADC",
          "schemaVersion": "3.50.0",
            "${tenant}": {
              "class": "Tenant",
              "${fullname}": {
                "class": "Application",
                "vs_${fullname}": {
                  "layer4": "udp",
                  "pool": "pool_$fullname",
                  "translateServerAddress": true,
                  "translateServerPort": true,
                  "class": "Service_UDP",
                  "profileUDP": {
                      "use": "client_udp_$fullname"
                  },
                  "shareAddresses": true,
                  "virtualAddresses": [
                      "$virtualAddress"
                  ],
                  "virtualPort": $virtualPort,
                  "persistenceMethods": [
                  ${persistenceValueAS3}
                  ],
                  "snat": {
                    "bigip": "/Common/generalSNAT"
                  }                  
                },             
                "client_udp_$fullname": {
                  "idleTimeout": $clientTimeout,
                  "class": "UDP_Profile"
                },
                "pool_$fullname": {
                    "loadBalancingMode": "${lbMethodAlgorithm}",
                    "members": [
                        $poolMembersJson
                    ],
                    "monitors": [
                        {
                            "bigip": "/Common/gateway_icmp"
                        }
                    ],
                    "class": "Pool"
                }
              }
            }
        }
    }
"@
        }
"DNS" {
    #Write-Host "Selecting UDP template"
                @"
    {
        "class": "AS3",
        "action": "deploy",
        "persist": true,
        "declaration": {
          "class": "ADC",
          "schemaVersion": "3.50.0",
            "${tenant}": {
              "class": "Tenant",
              "${fullname}": {
                "class": "Application",
                "vs_${fullname}": {
                    "layer4": "udp",
                    "pool": "pool_$fullname",
                    "translateServerAddress": true,
                    "translateServerPort": true,
                    "class": "Service_UDP",
                    "profileUDP": {
                        "use": "client_udp_$fullname"
                    },
                    "profileDNS": {
                      "use": "dns_$fullname"
                    },
                    "shareAddresses": true,
                    "virtualAddresses": [
                        "$virtualAddress"
                    ],
                    "virtualPort": $virtualPort,
                    "persistenceMethods": [
                    ${persistenceValueAS3}
                    ],
                    "snat": {
                      "bigip": "/Common/generalSNAT"
                    }                    
                  },          
                  "client_udp_$fullname": {
                    "idleTimeout": $clientTimeout,
                    "class": "UDP_Profile"
                  },
                  "dns_$fullname": {
                    "class": "DNS_Profile"
                  },
                  "monitor_dns_$fullname": {
                    "class": "Monitor",
                    "monitorType": "dns",
                    "queryName": "$dnsQuery",
                    "queryType": "$dnsQueryType"
                  },
                  "pool_$fullname": {
                      "loadBalancingMode": "${lbMethodAlgorithm}",
                      "members": [
                          $poolMembersJson
                      ],
                      "monitors": [
                          {
                              "use": "monitor_dns_$fullname"
                          }
                      ],
                      "class": "Pool"
                  }
                }
              }
            }
        }
"@
        }
        "SSL_BRIDGE" { 
            #Write-Host "Selecting SSL_BRIDGE template"
            @"
{
    "class": "AS3",
    "action": "deploy",
    "persist": true,
    "declaration": {
        "class": "ADC",
        "schemaVersion": "3.50.0",
        "${tenant}": {
          "class": "Tenant",
          "${fullname}": {
            "class": "Application",
            "vs_${fullname}": {
                "layer4": "tcp",
                "pool": "pool_$fullname",
                "translateServerAddress": true,
                "translateServerPort": true,
                "class": "Service_TCP",
                "profileTCP": {
                  "ingress": {
                    "use": "client_tcp_$fullname"
                  },
                  "egress": {
                    "use": "server_tcp_$fullname"
                  }
                },
                "shareAddresses": true,
                "virtualAddresses": [
                    "$virtualAddress"
                ],
                "virtualPort": $virtualPort,
                "persistenceMethods": [
                ${persistenceValueAS3}
                ],
                "snat": {
                  "bigip": "/Common/generalSNAT"
                }
            },
            "pool_$fullname": {
                "loadBalancingMode": "${lbMethodAlgorithm}",
                "members": [
                    $poolMembersJson
                ],
                "monitors": [
                    {
                        "bigip": "/Common/tcp"
                    }
                ],
                "class": "Pool"
            },
            "server_tcp_$fullname": {
              "idleTimeout": $serverTimeout,
              "class": "TCP_Profile"
            },
            "client_tcp_$fullname": {
              "idleTimeout": $clientTimeout,
              "class": "TCP_Profile"
            }
        }
    }
}
"@
        }
        "SSL" { 
            #Write-Host "Selecting SSL template"
            @"
            {
              "class": "AS3",
              "action": "deploy",
              "persist": true,
              "declaration": {
                "class": "ADC",
                "schemaVersion": "3.50.0",
              "${tenant}": {
                "class": "Tenant",
                "${fullname}": {
                  "class": "Application",
                  "certkey-${fullname}": {
                    "class": "Certificate",
                    "certificate": "-----BEGIN CERTIFICATE-----\nMIIDQjCCAiqgAwIBAgIJAL+K1BWc0WXGMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNV\nBAYTAkJSMQ4wDAYDVQQIDAVHb2lhczEQMA4GA1UEBwwHR29pYW5pYTETMBEGA1UE\nCgwKRjVMQUIgTHRkYTELMAkGA1UECwwCSVQxEjAQBgNVBAMMCWY1bGFiLmNvbTAe\nFw0yMzAxMDkxNDEzMTVaFw0yNDAxMDkxNDEzMTVaMD0xCzAJBgNVBAYTAlVTMRUw\nEwYDVQQKDAxGNSBMYWIsIEluYy4xFzAVBgNVBAMMDmFwcDEuZjV0cm4uY29tMIIB\nIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyOmlSk6lqvkG+g3nZsnTgtE0\n2U67FlfLQYY/DkqEKToG5j3H+JPmOfvi/XLsUf1seP37pFLau5CDhaHrKc+KjJID\nH1wfcRj+pzIKdA2hPps3x7AP5iYMJSgdrvMetoeCdadjU4MzbFar6i2b5iUoFtgH\nOwc2BADLLwdYrSIc/YOyQaoTnERcFyjzktu+X82i8EBviJ5UvgVuvePGcnKSzyA2\nG6CMDsR6j63oKQzyU3wHkM0xj1O9CWyM2qxFhq6EGOJub3+8gyJlmRZ00yW0usoj\nxYSleeG59ZoTKLQ2pkfjGKHm96Sf6W7e5/tM5lcRyU2P+CDGFp8QqGZfL5DfxQID\nAQABox0wGzAZBgNVHREEEjAQgg5hcHAxLmY1dHJuLmNvbTANBgkqhkiG9w0BAQsF\nAAOCAQEA2d6BfUPbdgTLQuU85RxoY7DkSLiSeH1G4mQhxdQ96oHpupsG3N5yLDSP\nwuKvTe3g+i7VcM7QcXlkkuR9+f2BzRiojEG5ritGSWbnaKz2X2siUiD5kGZHyaKT\nD30i0dvK22kgz6ilosXQqygbWMnXbdccxxgc2J3nU4b5U1rIoLKmX7WQqPbgnnfS\neWQ3A9Up2OUOZGGwK5CS9HCWBM5hzyg27k8zmjkNL6j6RsA5SeMNVW1nUYnNbWRt\nhxgjhIlscz1DrGJYHtNy74WAxhuMqCRqGzDVe2jIRLeaz3Ql55JDMlzo0b/rQU31\nEYblDPLPCQ97BUTauDFdNEg8b4YHow==\n-----END CERTIFICATE-----\n",
                    "privateKey": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDI6aVKTqWq+Qb6\nDedmydOC0TTZTrsWV8tBhj8OSoQpOgbmPcf4k+Y5++L9cuxR/Wx4/fukUtq7kIOF\noespz4qMkgMfXB9xGP6nMgp0DaE+mzfHsA/mJgwlKB2u8x62h4J1p2NTgzNsVqvq\nLZvmJSgW2Ac7BzYEAMsvB1itIhz9g7JBqhOcRFwXKPOS275fzaLwQG+InlS+BW69\n48ZycpLPIDYboIwOxHqPregpDPJTfAeQzTGPU70JbIzarEWGroQY4m5vf7yDImWZ\nFnTTJbS6yiPFhKV54bn1mhMotDamR+MYoeb3pJ/pbt7n+0zmVxHJTY/4IMYWnxCo\nZl8vkN/FAgMBAAECggEBAL450mFXs6382Ok67uS4pUXQFQzHaYYPHAhvNhau4REz\nusKWrlaimjI+Vr4H6M78do7cUz1ToXxDqPOGymSs945+1OwFSlPICZx+Wb1mBkyD\npD2yamtLjOZFZE14LZU/GnuRQA8bQz4Jlf5Err4qYhm28qml+zOxGK/vcbuDeBVi\nxD+152UjhA+B/TLIYRRYb5kVEe5JUIQ5rYxfCdbHyDxhyEZK9KxRZBJDA1mwlGGZ\np19nVD7Dpou1xxvxt62ekSyxo3//Z0MC5xWnIZlnHSW8dM0MInLYYAjtT8lZtvk6\ngtTX1KC8xRI64fWw03z8Q07QQXwUy42JA2g1pif/kKECgYEA9XL9yE5tLEPVZWc6\nJxVOkYUoPR3iAtYu2oW8X9SnkLxuVQJIsV2hVPn2+2qpTfb5PL48D5LUEcY5TqiF\nr572bcWpi1IWoEFAVKTax2dHY7vDVxZ5MCBBPACQJMeiDkPhRgFJ+fboLKhDHtMr\nTPyIRQYVTqA08XkQARsdm7qXNgkCgYEA0YyPHPK+IpchBYjLQ75rqUj7Ibs77DGr\neamT4jaHouf/n85rrqZNmAorKYDSlqJ3EC2rplHmXPTWIdVSCML0WvqQIZlj+ywR\n9MxjBclFGrppG2+eEbUwHT8xDCrtmFJJyI61NFyYkPJhMF3O7R8upkyG5I+BObzV\nPPQgv1dL6t0CgYEA3HrdCS+Z1edhK2Oc0zrKhuFsEepj+VRYZic33YVyuArruSUC\nE4EdyO15NMLNLqGppSzlWr/0C7taAxRScj2C83xZHjMw6+dxWBd2ByT49dfWUsZ3\nOgnfT3zZ/o/tPI8xLuc9gnKOgH7tPCVIgjFeX1JllWlH5ZlwDO5EnHzyE7ECgYB3\nv+eZF29ovQz16LKgSBWmbDp3kFQyKkBgCnSkdZ0Vj5cZcBFBgXAeTtFTqnat9rIr\n4K2TIoKO5KvqMcnrj92skDwFt27XftvUFWkRSW/gUl72etbOL8kLLa2N0ops3bmk\nj0kmXzQgwSKhTTqPb55tEpaTzx5+LFd/udNtBSoxUQKBgE8kjCaGQZHzOphWvzHN\n5i0zJHB0xsE1BH7lZIdxzZWmcRysOmxH++zF+Vu7qPohjdHvPuOkGUPHtqkn+Krd\nhDCls5g7xB9Y4W79B7ILK49QXhiYAuC4MUT0Ug+fFdDZXFczCpAajCNBQ4CLW8Pn\nWT9YuBqSfBW9tx0IpNZ2pn48\n-----END PRIVATE KEY-----\n"
                },
                  "cssl_${fullname}": {
                    "certificates": [
                      {
                        "certificate": "certkey-${fullname}"
                      }
                    ],
                    "class": "TLS_Server",
                    "cipherGroup": {
                      "bigip": "/Common/Shared/approved-cipher-group-001"
                    }
                  },
                  "vs_${fullname}": {
                    "class": "Service_HTTPS",
                    "pool": "pool_$fullname",
                    "translateServerAddress": true,
                    "translateServerPort": true,
                    "shareAddresses": true,
                    "redirect80": false,
                    "virtualAddresses": [
                      "$virtualAddress"
                    ],
                    "virtualPort": $virtualPort,
                    "serverTLS": "cssl_$fullname",
                    "profileTCP": {
                      "ingress": {
                        "use": "client_tcp_$fullname"
                      },
                      "egress": {
                        "use": "server_tcp_$fullname"
                      }
                    },
                    "clientTLS": {
                      "bigip": "/Common/serverssl"
                    },
                    "profileHTTP": {
                      "bigip": "/Common/Shared/http_xff_hsts_standardized"
                    },
                    "persistenceMethods": [
                      ${persistenceValueAS3}
                    ],
                    "snat": {
                      "bigip": "/Common/generalSNAT"
                    }
                  },
                  "pool_$fullname": {
                    "loadBalancingMode": "${lbMethodAlgorithm}",
                    "members": [
                      $poolMembersJson
                    ],
                    "class": "Pool",
                    "monitors": [
                      "https"
                    ]
                  },
                  "server_tcp_$fullname": {
                    "idleTimeout": $serverTimeout,
                    "class": "TCP_Profile"
                  },
                  "client_tcp_$fullname": {
                    "idleTimeout": $clientTimeout,
                    "class": "TCP_Profile"
                  }
                }
              }
            }
          }
"@
    }
    "SSL_TCP" { 
            #Write-Host "Selecting SSL template"
            @"
            {
              "class": "AS3",
              "action": "deploy",
              "persist": true,
              "declaration": {
                "class": "ADC",
                "schemaVersion": "3.50.0",
              "${tenant}": {
                "class": "Tenant",
                "${fullname}": {
                  "class": "Application",
                  "certkey-${fullname}": {
                    "class": "Certificate",
                    "certificate": "-----BEGIN CERTIFICATE-----\nMIIDQjCCAiqgAwIBAgIJAL+K1BWc0WXGMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNV\nBAYTAkJSMQ4wDAYDVQQIDAVHb2lhczEQMA4GA1UEBwwHR29pYW5pYTETMBEGA1UE\nCgwKRjVMQUIgTHRkYTELMAkGA1UECwwCSVQxEjAQBgNVBAMMCWY1bGFiLmNvbTAe\nFw0yMzAxMDkxNDEzMTVaFw0yNDAxMDkxNDEzMTVaMD0xCzAJBgNVBAYTAlVTMRUw\nEwYDVQQKDAxGNSBMYWIsIEluYy4xFzAVBgNVBAMMDmFwcDEuZjV0cm4uY29tMIIB\nIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyOmlSk6lqvkG+g3nZsnTgtE0\n2U67FlfLQYY/DkqEKToG5j3H+JPmOfvi/XLsUf1seP37pFLau5CDhaHrKc+KjJID\nH1wfcRj+pzIKdA2hPps3x7AP5iYMJSgdrvMetoeCdadjU4MzbFar6i2b5iUoFtgH\nOwc2BADLLwdYrSIc/YOyQaoTnERcFyjzktu+X82i8EBviJ5UvgVuvePGcnKSzyA2\nG6CMDsR6j63oKQzyU3wHkM0xj1O9CWyM2qxFhq6EGOJub3+8gyJlmRZ00yW0usoj\nxYSleeG59ZoTKLQ2pkfjGKHm96Sf6W7e5/tM5lcRyU2P+CDGFp8QqGZfL5DfxQID\nAQABox0wGzAZBgNVHREEEjAQgg5hcHAxLmY1dHJuLmNvbTANBgkqhkiG9w0BAQsF\nAAOCAQEA2d6BfUPbdgTLQuU85RxoY7DkSLiSeH1G4mQhxdQ96oHpupsG3N5yLDSP\nwuKvTe3g+i7VcM7QcXlkkuR9+f2BzRiojEG5ritGSWbnaKz2X2siUiD5kGZHyaKT\nD30i0dvK22kgz6ilosXQqygbWMnXbdccxxgc2J3nU4b5U1rIoLKmX7WQqPbgnnfS\neWQ3A9Up2OUOZGGwK5CS9HCWBM5hzyg27k8zmjkNL6j6RsA5SeMNVW1nUYnNbWRt\nhxgjhIlscz1DrGJYHtNy74WAxhuMqCRqGzDVe2jIRLeaz3Ql55JDMlzo0b/rQU31\nEYblDPLPCQ97BUTauDFdNEg8b4YHow==\n-----END CERTIFICATE-----\n",
                    "privateKey": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDI6aVKTqWq+Qb6\nDedmydOC0TTZTrsWV8tBhj8OSoQpOgbmPcf4k+Y5++L9cuxR/Wx4/fukUtq7kIOF\noespz4qMkgMfXB9xGP6nMgp0DaE+mzfHsA/mJgwlKB2u8x62h4J1p2NTgzNsVqvq\nLZvmJSgW2Ac7BzYEAMsvB1itIhz9g7JBqhOcRFwXKPOS275fzaLwQG+InlS+BW69\n48ZycpLPIDYboIwOxHqPregpDPJTfAeQzTGPU70JbIzarEWGroQY4m5vf7yDImWZ\nFnTTJbS6yiPFhKV54bn1mhMotDamR+MYoeb3pJ/pbt7n+0zmVxHJTY/4IMYWnxCo\nZl8vkN/FAgMBAAECggEBAL450mFXs6382Ok67uS4pUXQFQzHaYYPHAhvNhau4REz\nusKWrlaimjI+Vr4H6M78do7cUz1ToXxDqPOGymSs945+1OwFSlPICZx+Wb1mBkyD\npD2yamtLjOZFZE14LZU/GnuRQA8bQz4Jlf5Err4qYhm28qml+zOxGK/vcbuDeBVi\nxD+152UjhA+B/TLIYRRYb5kVEe5JUIQ5rYxfCdbHyDxhyEZK9KxRZBJDA1mwlGGZ\np19nVD7Dpou1xxvxt62ekSyxo3//Z0MC5xWnIZlnHSW8dM0MInLYYAjtT8lZtvk6\ngtTX1KC8xRI64fWw03z8Q07QQXwUy42JA2g1pif/kKECgYEA9XL9yE5tLEPVZWc6\nJxVOkYUoPR3iAtYu2oW8X9SnkLxuVQJIsV2hVPn2+2qpTfb5PL48D5LUEcY5TqiF\nr572bcWpi1IWoEFAVKTax2dHY7vDVxZ5MCBBPACQJMeiDkPhRgFJ+fboLKhDHtMr\nTPyIRQYVTqA08XkQARsdm7qXNgkCgYEA0YyPHPK+IpchBYjLQ75rqUj7Ibs77DGr\neamT4jaHouf/n85rrqZNmAorKYDSlqJ3EC2rplHmXPTWIdVSCML0WvqQIZlj+ywR\n9MxjBclFGrppG2+eEbUwHT8xDCrtmFJJyI61NFyYkPJhMF3O7R8upkyG5I+BObzV\nPPQgv1dL6t0CgYEA3HrdCS+Z1edhK2Oc0zrKhuFsEepj+VRYZic33YVyuArruSUC\nE4EdyO15NMLNLqGppSzlWr/0C7taAxRScj2C83xZHjMw6+dxWBd2ByT49dfWUsZ3\nOgnfT3zZ/o/tPI8xLuc9gnKOgH7tPCVIgjFeX1JllWlH5ZlwDO5EnHzyE7ECgYB3\nv+eZF29ovQz16LKgSBWmbDp3kFQyKkBgCnSkdZ0Vj5cZcBFBgXAeTtFTqnat9rIr\n4K2TIoKO5KvqMcnrj92skDwFt27XftvUFWkRSW/gUl72etbOL8kLLa2N0ops3bmk\nj0kmXzQgwSKhTTqPb55tEpaTzx5+LFd/udNtBSoxUQKBgE8kjCaGQZHzOphWvzHN\n5i0zJHB0xsE1BH7lZIdxzZWmcRysOmxH++zF+Vu7qPohjdHvPuOkGUPHtqkn+Krd\nhDCls5g7xB9Y4W79B7ILK49QXhiYAuC4MUT0Ug+fFdDZXFczCpAajCNBQ4CLW8Pn\nWT9YuBqSfBW9tx0IpNZ2pn48\n-----END PRIVATE KEY-----\n"
                },
                  "cssl_${fullname}": {
                    "certificates": [
                      {
                        "certificate": "certkey-${fullname}"
                      }
                    ],
                    "class": "TLS_Server",
                    "cipherGroup": {
                      "bigip": "/Common/Shared/approved-cipher-group-001"
                    }
                  },
                  "vs_${fullname}": {
                    "class": "Service_HTTPS",
                    "pool": "pool_$fullname",
                    "translateServerAddress": true,
                    "translateServerPort": true,
                    "shareAddresses": true,
                    "redirect80": false,
                    "virtualAddresses": [
                      "$virtualAddress"
                    ],
                    "virtualPort": $virtualPort,
                    "serverTLS": "cssl_$fullname",
                    "profileTCP": {
                      "ingress": {
                        "use": "client_tcp_$fullname"
                      },
                      "egress": {
                        "use": "server_tcp_$fullname"
                      }
                    },
                    "clientTLS": {
                      "bigip": "/Common/serverssl"
                    },
                    "profileHTTP": {
                      "bigip": "/Common/Shared/http_xff_hsts_standardized"
                    },
                    "persistenceMethods": [
                      ${persistenceValueAS3}
                    ],
                    "snat": {
                      "bigip": "/Common/generalSNAT"
                    }
                  },
                  "pool_$fullname": {
                    "loadBalancingMode": "${lbMethodAlgorithm}",
                    "members": [
                      $poolMembersJson
                    ],
                    "class": "Pool",
                    "monitors": [
                      "https"
                    ]
                  },
                  "server_tcp_$fullname": {
                    "idleTimeout": $serverTimeout,
                    "class": "TCP_Profile"
                  },
                  "client_tcp_$fullname": {
                    "idleTimeout": $clientTimeout,
                    "class": "TCP_Profile"
                  }
                }
              }
            }
          }
"@
    }
    "HTTP" {    
        #Write-Host "Selecting HTTP template"
        @"
        {
            "class": "AS3",
            "action": "deploy",
            "persist": true,
            "declaration": {
              "class": "ADC",
              "schemaVersion": "3.50.0",
              "${tenant}": {
                "class": "Tenant",
                "${fullname}": {
                  "class": "Application",
                  "vs_${fullname}": {
                    "class": "Service_HTTP",
                    "layer4": "tcp",
                    "pool": "pool_$fullname",
                    "translateServerAddress": true,
                    "translateServerPort": true,
                    "shareAddresses": true,
                    "virtualAddresses": [
                      "$virtualAddress"
                    ],
                    "virtualPort": $virtualPort,
                    "profileHTTP": {
                      "use": "/Common/Shared/http_xff_standardized"
                    },
                    "profileTCP": {
                      "ingress": {
                        "use": "client_tcp_$fullname"
                      },
                      "egress": {
                        "use": "server_tcp_$fullname"
                      }
                    },
                    "persistenceMethods": [
                    ${persistenceValueAS3}
                    ],
                    "snat": {
                      "bigip": "/Common/generalSNAT"
                    }
                  },
                  "pool_$fullname": {
                    "loadBalancingMode": "${lbMethodAlgorithm}",
                    "members": [
                      $poolMembersJson
                    ],
                    "class": "Pool",
                    "monitors": [
                      "http"
                    ]
                  },
                  "server_tcp_$fullname": {
                    "idleTimeout": $serverTimeout,
                    "class": "TCP_Profile"
                  },
                  "client_tcp_$fullname": {
                    "idleTimeout": $clientTimeout,
                    "class": "TCP_Profile"
                  }
                }
              }
            }
          }
"@
    }
    "REDIRECT" {    
        #Write-Host "Selecting HTTP template"
        @"
        {
            "class": "AS3",
            "action": "deploy",
            "persist": true,
            "declaration": {
              "class": "ADC",
              "schemaVersion": "3.50.0",
              "${tenant}": {
                "class": "Tenant",
                "${fullname}": {
                  "class": "Application",
                  "vs_${fullname}": {
                    "class": "Service_HTTP",
                    "layer4": "tcp",
                    "translateServerAddress": true,
                    "translateServerPort": true,
                    "shareAddresses": true,
                    "virtualAddresses": [
                      "$virtualAddress"
                    ],
                    "virtualPort": $virtualPort,
                    "profileHTTP": {
                      "use": "/Common/Shared/http_xff_standardized"
                    },
                    "profileTCP": {
                      "ingress": {
                        "use": "client_tcp_$fullname"
                      },
                      "egress": {
                        "use": "server_tcp_$fullname"
                      }
                    },
                    "snat": {
                      "bigip": "/Common/generalSNAT"
                    },
                    "iRules": [
                      {
                        "bigip": "/Common/_sys_https_redirect"
                      }
                    ]
                  },
                  "server_tcp_$fullname": {
                    "idleTimeout": $serverTimeout,
                    "class": "TCP_Profile"
                  },
                  "client_tcp_$fullname": {
                    "idleTimeout": $clientTimeout,
                    "class": "TCP_Profile"
                  }
                }
              }
            }
          }
"@
    }
        Default { }
    }
    #write-host "Template: $template"
    if ($template) {
        Write-Host "Conversion successful"
        # Perform the conversion using the selected template
        $convertedContent = $template

        # Write the converted content to a new file with .as3 extension
        $outputFile = $_.FullName -replace '\.([^\.]+)$', '_as3_.json'
        $convertedContent | Set-Content -Path $outputFile
    } else {
        Write-Host "Conversion failed"
    }
}
